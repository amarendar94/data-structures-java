package com.codewithmosh;

public class Main {
    public static void main(String[] names) {
        var s = new Search();
        int[] n = { 1 };
        System.out.println(s.binarySearchRec(n, 1));
    }
}

